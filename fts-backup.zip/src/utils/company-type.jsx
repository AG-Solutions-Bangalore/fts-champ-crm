const company_type = [
    "Private",
    "Public",
    "PSU",
    "Trust",
    "Society",
    "Others",
  ];
  export default company_type ;