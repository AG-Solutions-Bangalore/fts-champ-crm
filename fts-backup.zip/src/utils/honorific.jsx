const honorific = [
    "Shri",
    "Smt.",
    "Kum",
    "Dr.",
  ];
  export default honorific ;