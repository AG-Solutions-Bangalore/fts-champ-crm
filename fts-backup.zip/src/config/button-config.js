export const ButtonConfig = {
  backgroundColor: "bg-blue-400",
  hoverBackgroundColor: "hover:bg-blue-500",
  textColor: "text-black",
  cardColor: "bg-blue-200",
  cardheaderColor: "bg-blue-200",
  cardLabel: "text-black",
  tableHeader: "bg-blue-200",
  tableLabel: "text-black",
  loginBackground: "bg-white",
  loginText: "text-black",
};
// export const ButtonConfig = {
//   backgroundColor: "bg-blue-400",
//   hoverBackgroundColor: "hover:bg-blue-500",
//   textColor: "text-black",
//   cardColor: "bg-blue-200",
//   cardheaderColor: "bg-blue-200",
//   cardLabel: "text-black",
//   tableHeader: "bg-blue-200",
//   tableLabel: "text-black",
//   loginBackground: "bg-white",
//   loginText: "text-black",
// };
