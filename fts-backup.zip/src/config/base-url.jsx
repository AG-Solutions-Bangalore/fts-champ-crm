
 

const BASE_URL = "https://agsrb.online/api1/public";
// const BASE_URL = "https://ftschamp.com/crmapi/public";


export default BASE_URL;

