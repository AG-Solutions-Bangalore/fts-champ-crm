import React from 'react'

const MembershipActive = () => {
  return (
    <div>MembershipActive</div>
  )
}

export default MembershipActive