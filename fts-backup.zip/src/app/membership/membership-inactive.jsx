import React from 'react'

const MemberShipInactive = () => {
  return (
    <div>MemberShipInactive</div>
  )
}

export default MemberShipInactive